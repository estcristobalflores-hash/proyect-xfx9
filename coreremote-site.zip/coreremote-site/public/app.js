(() => {
  const connectButton = document.querySelector('#connect-button');
  const pinInput = document.querySelector('#client-pin');
  const passwordInput = document.querySelector('#agent-password');
  const message = document.querySelector('#form-message');

  if (!connectButton || !pinInput || !passwordInput || !message) return;

  connectButton.addEventListener('click', () => {
    message.hidden = false;

    if (!pinInput.value.trim()) {
      message.textContent = 'Escribe el PIN del equipo para continuar.';
      pinInput.focus();
      return;
    }

    if (!passwordInput.value) {
      message.textContent = 'Escribe la contraseña configurada en el agente.';
      passwordInput.focus();
      return;
    }

    passwordInput.value = '';
    message.textContent = 'El protocolo del agente aún debe integrarse. No se envió ni guardó tu contraseña.';
    passwordInput.focus();
  });
})();

// Acordeón de descargas
(() => {
  document.querySelectorAll('.dl-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      const panel = document.getElementById(btn.getAttribute('aria-controls'));
      btn.setAttribute('aria-expanded', String(!expanded));
      panel.hidden = expanded;
    });
  });
})();
