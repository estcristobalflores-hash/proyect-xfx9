/**
 * passwd.js
 * Convierte el input de acceso en campo tipo password (muestra puntos).
 * Para desactivarlo: borra este archivo y quita el <script> en index.html.
 */
(function () {
  const input = document.querySelector('.access-input');
  if (!input) return;

  // Cambiar a tipo password para que el navegador muestre puntos
  input.type = 'password';

  // El placeholder visual sigue funcionando: al enfocar limpia, al salir restaura
  // (esa lógica ya está en app.js, solo nos aseguramos que el tipo sea correcto)

  // Si el campo tiene el valor por defecto (placeholder), mostrarlo como texto
  // para que se lea, y solo ocultarlo cuando el usuario empiece a escribir su código
  const defaultValue = 'login@terminal-temple (login)';

  function updateType() {
    if (input.value === defaultValue || input.value === '') {
      input.type = 'text';
    } else {
      input.type = 'password';
    }
  }

  // Al enfocar: limpia y activa password
  input.addEventListener('focus', () => {
    if (input.value === defaultValue) {
      input.value = '';
    }
    input.type = 'password';
  });

  // Al perder foco: si quedó vacío, restaura placeholder como texto legible
  input.addEventListener('blur', () => {
    if (input.value.trim() === '') {
      input.type = 'text';
      input.value = defaultValue;
    }
  });

  // Mientras escribe: mantener tipo password
  input.addEventListener('input', () => {
    input.type = 'password';
  });

  // Estado inicial
  updateType();
})();
